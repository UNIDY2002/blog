#include<iostream>
using namespace std;

int main(){
  freopen("taxi.in","r",stdin); freopen("taxi.out","w",stdout);
  
  return 0;
}
