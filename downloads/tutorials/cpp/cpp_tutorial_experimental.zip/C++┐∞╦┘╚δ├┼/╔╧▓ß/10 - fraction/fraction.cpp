#include<bits/stdc++.h>
using namespace std;

int main(){
  freopen("fraction.in","r",stdin); freopen("fraction.out","w",stdout);
  
  return 0;
}
