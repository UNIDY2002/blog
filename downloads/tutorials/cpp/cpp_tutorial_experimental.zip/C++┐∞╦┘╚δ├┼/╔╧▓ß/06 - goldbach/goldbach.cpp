#include<iostream>
using namespace std;

int main(){
  freopen("goldbach.in","r",stdin); freopen("goldbach.out","w",stdout);
  
  return 0;
}
