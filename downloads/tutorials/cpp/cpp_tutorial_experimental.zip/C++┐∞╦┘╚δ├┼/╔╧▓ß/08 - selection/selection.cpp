#include<iostream>
using namespace std;

int main(){
  freopen("selection.in","r",stdin); freopen("selection.out","w",stdout);
  
  return 0;
}
