#include<bits/stdc++.h>
using namespace std;

int main(){
  freopen("student.in","r",stdin); freopen("student.out","w",stdout);
  
  return 0;
}
