#include<iostream>
using namespace std;

int main(){
  freopen("primetable.in","r",stdin); freopen("primetable.out","w",stdout);
  
  return 0;
}
