#include<iostream>
using namespace std;

int main(){
  freopen("isprime.in","r",stdin); freopen("isprime.out","w",stdout);
  
  return 0;
}
